# butterworth-lowpass-filter
c code for butterworth lowpass filter


2nd order butterworth lowpass filter with phase sensitive demodulation
after filter we got in phase and quadarature phase signal , find amplitude by adding squre of in-phase and quadrature-phase signals and take its sqrt.
